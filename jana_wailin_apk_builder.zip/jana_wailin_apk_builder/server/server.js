import http from 'node:http';
const PORT=process.env.PORT||8787;
const API_KEY=process.env.OPENAI_API_KEY;
const MODEL=process.env.OPENAI_MODEL||'gpt-4.1-mini';
const MAX=11*1024*1024;
function send(res,status,obj){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Access-Control-Allow-Origin':process.env.ALLOWED_ORIGIN||'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'POST,GET,OPTIONS','Cache-Control':'no-store'});res.end(JSON.stringify(obj));}
const server=http.createServer(async(req,res)=>{
 if(req.method==='OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Origin':process.env.ALLOWED_ORIGIN||'*','Access-Control-Allow-Headers':'Content-Type','Access-Control-Allow-Methods':'POST,GET,OPTIONS'});return res.end();}
 if(req.method==='GET'&&req.url==='/health')return send(res,200,{ok:true,service:'jana-wailin-ai'});
 if(req.method!=='POST'||req.url!='/api/analyze-image')return send(res,404,{error:'المسار غير موجود'});
 if(!API_KEY)return send(res,503,{error:'الخادم يحتاج إلى إعداد OPENAI_API_KEY في متغيرات البيئة.'});
 let raw='';req.on('data',chunk=>{raw+=chunk;if(raw.length>MAX){send(res,413,{error:'حجم الطلب أكبر من الحد المسموح.'});req.destroy();}});
 req.on('end',async()=>{try{
  const body=JSON.parse(raw||'{}');const image=body.image;
  if(typeof image!=='string'||!/^data:image\/(png|jpeg|jpg|webp);base64,/.test(image))return send(res,400,{error:'أرسل صورة PNG أو JPEG أو WEBP بصيغة data URL.'});
  if(image.length>10*1024*1024)return send(res,413,{error:'الصورة كبيرة جدًا.'});
  const context=`معلومات المستخدم: النبات=${body.plant||'غير معروف'}؛ موضع الأعراض=${body.part||'غير محدد'}؛ العرض=${body.symptom||'غير محدد'}؛ الري=${body.watering||'غير محدد'}؛ العمر=${body.age||'غير محدد'}؛ المنطقة=${body.region||'غير محددة'}.`;
  const prompt=`أنت مساعد إرشاد زراعي عربي حذر. حلل الصورة بوصفها مؤشرات محتملة لا تشخيصًا مؤكدًا. اكتب بالعربية الواضحة وباختصار منظم: (1) ما تراه بالصورة، (2) النبات المحتمل إن أمكن مع درجة ثقة لفظية، (3) 2-4 أسباب محتملة مع التفريق بينها، (4) فحوص آمنة إضافية، (5) خطوات وقاية عامة. لا تخترع جرعات مبيدات ولا توصي بمبيد محدد؛ اطلب مراجعة مهندس زراعي والملصق المحلي قبل أي مبيد. إذا كانت الصورة غير واضحة فقل ذلك صراحة. ${context}`;
  const api=await fetch('https://api.openai.com/v1/responses',{method:'POST',headers:{'Authorization':`Bearer ${API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:MODEL,input:[{role:'user',content:[{type:'input_text',text:prompt},{type:'input_image',image_url:image,detail:'high'}]}],max_output_tokens:700})});
  const data=await api.json();if(!api.ok)return send(res,502,{error:data.error?.message||'فشل مزود تحليل الصور.'});
  const text=(data.output||[]).flatMap(x=>x.content||[]).filter(x=>x.type==='output_text').map(x=>x.text).join('\n').trim();
  if(!text)return send(res,502,{error:'لم يرجع النموذج نتيجة نصية.'});return send(res,200,{analysis:text,model:MODEL,notice:'نتيجة احتمالية وليست تشخيصًا قطعيًا.'});
 }catch(e){return send(res,400,{error:'تعذر معالجة الطلب. تحقق من صيغة البيانات.'});}});
});
server.listen(PORT,()=>console.log(`Jana Wailin AI server listening on ${PORT}`));
